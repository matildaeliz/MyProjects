package homework1.pack2;


public class TaxAmountCalculation {

	private int taxamount;
	
	

	public int taxamounts(int baseamount, double grosssalary ) {
		
		
		if(0 <= baseamount && baseamount < 1000 || grosssalary <=1000 ) {
			 this.taxamount = 0;
			return taxamount;
		} if( 1000<= baseamount && baseamount <5000){
			this.taxamount = 100;
			return taxamount;
		}if(5000<= baseamount && baseamount < 10000 && grosssalary >1000) {
			this.taxamount = 200;
			return taxamount;
		}if(10000<= baseamount && grosssalary >1000) {
			this.taxamount = 400;
			return taxamount;
		}
		
		
		return 0;
		
		
	
	}

	
	
}

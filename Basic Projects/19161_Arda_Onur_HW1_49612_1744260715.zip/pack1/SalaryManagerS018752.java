package homework1.pack1;

import java.util.Scanner;

import homework1.pack2.InsuranceAmountCalculation;
import homework1.pack2.TaxAmountCalculation;

public class SalaryManagerS018752 {
	
 public static void main(String[] args) throws Exception {
   
	TaxAmountCalculation ac = new TaxAmountCalculation();
	InsuranceAmountCalculation av = new InsuranceAmountCalculation();
	
	
	String[] months = { "January", "February", "March", "April", "May","June", "July", "Agust", "September", "October", "November", "December"};
	
	
	
	// In this code, first an input is received and then this salary 
    //goes to other classes as parameters. From there, the taxes and insurances
    // return to main method  and are calculated and displayed on the console
	
	
	
	// An array was opened for months because using looping to have a smoother code layout
	// I used for loop because instead of manually printing one by one, I output them all on the console
	//At the same time, if the user enters a word, I used an exception for the system to give an error and correct the error.
	
	
	while(true) {
	try {	
    Scanner sc = new Scanner(System.in);                                               
                                                                                       
    System.out.println("-----------------------------------");                         
    System.out.print("Please Enter Monthly Gross Salary : ");

  
    double grosssalary = sc.nextDouble();
  

	

System.out.println("-----------------------------------");
for(int i = 0; i<12; i++) {
int baseamount = (int) (grosssalary*i);

int netsalary = (int) (grosssalary - ac.taxamounts(baseamount, grosssalary) - av.InsuranceAmount(grosssalary));
if(grosssalary > 1000 && netsalary <1000) {
	netsalary = 1000;
}
System.out.println("For Month " +  months[i] +":" +  "  Gross Salary : " + grosssalary +  "  Tax Amount :" + ac.taxamounts(baseamount, grosssalary) + 
"  Insurance Amount : " + av.InsuranceAmount(grosssalary) + " Net Salary :" + netsalary);

}

	}
	
	catch(Exception e){
   		
   		System.out.println("");
   		System.out.println("PLEASE ENTER A NUMBER!!!!");
   		
	}
	
	
	
 
}

}
}
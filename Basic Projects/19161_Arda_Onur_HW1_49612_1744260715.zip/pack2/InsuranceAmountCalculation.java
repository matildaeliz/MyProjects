package homework1.pack2;

public class InsuranceAmountCalculation {

	private static double insurance;
	
	
	
	public double InsuranceAmount(double grosssalary) {
		
		insurance = grosssalary * insuranceratioo(grosssalary);
		
		return insurance;
	}
	
	

	private static double insuranceratioo(double grosssalary) {
		
		
		if(0<=grosssalary && grosssalary < 500) {
			double insuranceratio = 0;
			return insuranceratio;
		} if(500<= grosssalary && grosssalary <2000 ) {
			double insuranceratio = 0.1;
			return insuranceratio;
		}if(2000<= grosssalary && grosssalary < 5000) {
			double insuranceratio = 0.2;
			return insuranceratio;
		}if(5000<= grosssalary) {
			double insuranceratio = 0.4;
			return insuranceratio;
		}
		return 0;
		





	}



	



	
}

